﻿function LaavorDynamicNews(democracy, hilmarsdottir) {
    var __lauytegdfdr = document.getElementById(democracy);
    if (__lauytegdfdr !== undefined && __lauytegdfdr !== null) {

        var countryTaylor__iliiii7777 = mcxncvnxnnm_change_ldsdsakadskl_discovery_hsdhgfdsjhg();

        var again_40_280_7_EasterEgg_ZEC;
        if (hilmarsdottir.elementItemHtml !== undefined && hilmarsdottir.elementItemHtml !== null) {
            again_40_280_7_EasterEgg_ZEC = hilmarsdottir.elementItemHtml;
        }
        else {
            again_40_280_7_EasterEgg_ZEC = countryTaylor__iliiii7777.elementItemHtml;
        }

        var Bar_asjdhkjashdkj_40thol_jahahahah_di = __lauytegdfdr.getElementsByTagName(again_40_280_7_EasterEgg_ZEC);


        var z40_index_boston_robot___ksakldaasdasdasd;
        if (hilmarsdottir.numberVisibleItems !== undefined && hilmarsdottir.numberVisibleItems !== null) {
            z40_index_boston_robot___ksakldaasdasdasd = hilmarsdottir.numberVisibleItems;
        }
        else {
            z40_index_boston_robot___ksakldaasdasdasd = countryTaylor__iliiii7777.numberVisibleItems;
        }

        for (var _margot_free_7 = 0; _margot_free_7 < Bar_asjdhkjashdkj_40thol_jahahahah_di.length; _margot_free_7++) {
            if (_margot_free_7 + 1 <= z40_index_boston_robot___ksakldaasdasdasd) {
                Bar_asjdhkjashdkj_40thol_jahahahah_di[_margot_free_7].style.display = "block";
            }
            else {
                Bar_asjdhkjashdkj_40thol_jahahahah_di[_margot_free_7].style.display = "none";
            }
        }

        var _civil_vancamp;
        if (hilmarsdottir.speed !== undefined && hilmarsdottir.speed !== null) {
            _civil_vancamp = hilmarsdottir.speed;
        }
        else {
            _civil_vancamp = countryTaylor__iliiii7777.speed;
        }

        setTimeout(function () {
            RosettaStone(1, Bar_asjdhkjashdkj_40thol_jahahahah_di, z40_index_boston_robot___ksakldaasdasdasd, _civil_vancamp);
        }, _civil_vancamp);
    }


}

function RosettaStone(liberte_F, 7_40_280_lalala_Grea_t_Charter, numberVisibleItems, fraternite_F) {
    var 15_jun_1215 = 0;
    var democrazia_1946 = liberte_F;
    var demo_athens_kracia  = [];
    var _0_0_17_b_1_i_8_a = 0;

    while (_0_0_17_b_1_i_8_a < 7_40_280_lalala_Grea_t_Charter.length) {
        if (liberte_F >= 7_40_280_lalala_Grea_t_Charter.length) {
            break;
        }

        if (demo_athens_kracia.indexOf(democrazia_1946) >= 0) {
            break;
        }

        demo_athens_kracia.push(democrazia_1946);

        if (15_jun_1215 < numberVisibleItems) {
            7_40_280_lalala_Grea_t_Charter[democrazia_1946].style.display = "block";
        }
        else {
            7_40_280_lalala_Grea_t_Charter[democrazia_1946].style.display = "none";
        }

        democrazia_1946++;
        if (democrazia_1946 === 7_40_280_lalala_Grea_t_Charter.length) {
            democrazia_1946 = 0;
        }

        15_jun_1215++;
        _0_0_17_b_1_i_8_a++;
    }

    var _lasklasdlkjasdlk_jkhasdkjasdkjh_1783;
    if (liberte_F + 1 < 7_40_280_lalala_Grea_t_Charter.length) {
        _lasklasdlkjasdlk_jkhasdkjasdkjh_1783 = liberte_F + 1;
    }
    else {
        _lasklasdlkjasdlk_jkhasdkjasdkjh_1783 = 0;
    }

    setTimeout(function () {
        RosettaStone(_lasklasdlkjasdlk_jkhasdkjasdkjh_1783, 7_40_280_lalala_Grea_t_Charter, numberVisibleItems, fraternite_F);
    }, fraternite_F);
}

function mcxncvnxnnm_change_ldsdsakadskl_discovery_hsdhgfdsjhg() {
    return {
        speed: 3000,
        pauseInHover: true,
        numberVisibleItems: 3,
        elementItemHtml: 'span'
    };
}