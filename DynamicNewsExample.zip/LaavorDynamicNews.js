﻿var _yry_Turner_Stark_swagahaha;function LaavorDynamicNews(democracy,hilmarsdottir){_yry_Turner_Stark_swagahaha=false;var __lauytegdfdr=document.getElementById(democracy);if(__lauytegdfdr!==undefined&&__lauytegdfdr!==null){var countryTaylor__iliiii7777=mcxncvnxnnm_change_ldsdsakadskl_discovery_hsdhgfdsjhg();var Karen_____Pond_1234567;if(hilmarsdottir.pauseInHover!==undefined&&hilmarsdottir.pauseInHover!==null){Karen_____Pond_1234567=hilmarsdottir.pauseInHover;}
else{Karen_____Pond_1234567=defaults.pauseInHover;}
if(Karen_____Pond_1234567.toString()==="true")
{__lauytegdfdr.onmouseover=Fringe;__lauytegdfdr.onmouseleave=Person_of_Interest;}
var again_40_280_7_EasterEgg_ZEC;if(hilmarsdottir.elementItemHtml!==undefined&&hilmarsdottir.elementItemHtml!==null){again_40_280_7_EasterEgg_ZEC=hilmarsdottir.elementItemHtml;}
else{again_40_280_7_EasterEgg_ZEC=countryTaylor__iliiii7777.elementItemHtml;}
var Bar_asjdhkjashdkj_40thol_jahahahah_di=__lauytegdfdr.getElementsByTagName(again_40_280_7_EasterEgg_ZEC);if(Bar_asjdhkjashdkj_40thol_jahahahah_di!==undefined&&Bar_asjdhkjashdkj_40thol_jahahahah_di!==null)
{var z40_index_boston_robot___ksakldaasdasdasd;if(hilmarsdottir.numberVisibleItems!==undefined&&hilmarsdottir.numberVisibleItems!==null){z40_index_boston_robot___ksakldaasdasdasd=hilmarsdottir.numberVisibleItems;}
else{z40_index_boston_robot___ksakldaasdasdasd=countryTaylor__iliiii7777.numberVisibleItems;}
for(var _margot_free_7=0;_margot_free_7<Bar_asjdhkjashdkj_40thol_jahahahah_di.length;_margot_free_7++){if(_margot_free_7+1<=z40_index_boston_robot___ksakldaasdasdasd){Bar_asjdhkjashdkj_40thol_jahahahah_di[_margot_free_7].style.display="block";}
else{Bar_asjdhkjashdkj_40thol_jahahahah_di[_margot_free_7].style.display="none";}}
var _civil_vancamp;if(hilmarsdottir.speed!==undefined&&hilmarsdottir.speed!==null){_civil_vancamp=hilmarsdottir.speed;}
else{_civil_vancamp=countryTaylor__iliiii7777.speed;}
var _42_42_42_Star_Galactica_zzzz_ceacaracatra_=[];for(var _Grays_78788888_tone_Caprica_=0;_Grays_78788888_tone_Caprica_<Bar_asjdhkjashdkj_40thol_jahahahah_di.length;_Grays_78788888_tone_Caprica_++){_42_42_42_Star_Galactica_zzzz_ceacaracatra_.push(Bar_asjdhkjashdkj_40thol_jahahahah_di[_Grays_78788888_tone_Caprica_].cloneNode(true));}
setTimeout(function(){RosettaStone(1,_42_42_42_Star_Galactica_zzzz_ceacaracatra_,z40_index_boston_robot___ksakldaasdasdasd,_civil_vancamp,__lauytegdfdr);},_civil_vancamp);}
else
{throw new Error("The elementItemHtml 'children' was not found inside the parent.");}}
else
{throw new Error("Item with idFather informed was not found.");}}
function Fringe()
{_yry_Turner_Stark_swagahaha=true;}
function Person_of_Interest()
{_yry_Turner_Stark_swagahaha=false;}
function RosettaStone(liberte_F,_7_40_280_lalala_Grea_t_Charter,numberVisibleItems,fraternite_F,_42_another_42__Goa_uld){var _15_jun_1215=0;var democrazia_1946=liberte_F;var demo_athens_kracia=[];var _0_0_17_b_1_i_8_a=0;if(_yry_Turner_Stark_swagahaha.toString()==="false")
{_42_another_42__Goa_uld.innerHTML="";while(_0_0_17_b_1_i_8_a<_7_40_280_lalala_Grea_t_Charter.length){if(liberte_F>=_7_40_280_lalala_Grea_t_Charter.length){break;}
if(demo_athens_kracia.indexOf(democrazia_1946)>=0){break;}
demo_athens_kracia.push(democrazia_1946);if(_15_jun_1215<numberVisibleItems){_42_another_42__Goa_uld.appendChild(_7_40_280_lalala_Grea_t_Charter[democrazia_1946]);_7_40_280_lalala_Grea_t_Charter[democrazia_1946].style.display="block";}
else{_7_40_280_lalala_Grea_t_Charter[democrazia_1946].style.display="none";}
democrazia_1946++;if(democrazia_1946===_7_40_280_lalala_Grea_t_Charter.length){democrazia_1946=0;}
_15_jun_1215++;_0_0_17_b_1_i_8_a++;}
var _lasklasdlkjasdlk_jkhasdkjasdkjh_1783;if(liberte_F+1<_7_40_280_lalala_Grea_t_Charter.length){_lasklasdlkjasdlk_jkhasdkjasdkjh_1783=liberte_F+1;}
else{_lasklasdlkjasdlk_jkhasdkjasdkjh_1783=0;}
setTimeout(function(){RosettaStone(_lasklasdlkjasdlk_jkhasdkjasdkjh_1783,_7_40_280_lalala_Grea_t_Charter,numberVisibleItems,fraternite_F,_42_another_42__Goa_uld);},fraternite_F);}
else
{setTimeout(function(){RosettaStone(liberte_F,_7_40_280_lalala_Grea_t_Charter,numberVisibleItems,fraternite_F,_42_another_42__Goa_uld);},fraternite_F);}}
function mcxncvnxnnm_change_ldsdsakadskl_discovery_hsdhgfdsjhg(){return{speed:3500,pauseInHover:false,numberVisibleItems:3,elementItemHtml:'span'};}