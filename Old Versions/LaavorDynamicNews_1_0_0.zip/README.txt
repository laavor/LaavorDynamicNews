UI Java Script to give productivity to your code.

www.laavor.com
Contact: support@laavor.com

OBS: It is not necessary to use JQuery.